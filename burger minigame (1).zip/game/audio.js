/* ===== BURGER BLITZ — retro WebAudio SFX (no asset files) ===== */
const SFX = (function(){
  let ctx = null, muted = false, sizzleNode = null, sizzleGain = null;
  function ac(){ if(!ctx){ try{ ctx = new (window.AudioContext||window.webkitAudioContext)(); }catch(e){} } return ctx; }

  function blip(freq, dur, type, vol, slideTo){
    if (muted) return; const c = ac(); if(!c) return;
    const o = c.createOscillator(), g = c.createGain();
    o.type = type || 'square'; o.frequency.value = freq;
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, c.currentTime + dur);
    g.gain.value = vol || 0.12;
    g.gain.setValueAtTime(g.gain.value, c.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + dur);
    o.connect(g); g.connect(c.destination);
    o.start(); o.stop(c.currentTime + dur);
  }
  function noiseBurst(dur, vol, lp){
    if (muted) return; const c = ac(); if(!c) return;
    const n = c.sampleRate * dur, buf = c.createBuffer(1, n, c.sampleRate), d = buf.getChannelData(0);
    for (let i=0;i<n;i++) d[i] = (Math.random()*2-1) * (1 - i/n);
    const src = c.createBufferSource(); src.buffer = buf;
    const f = c.createBiquadFilter(); f.type='lowpass'; f.frequency.value = lp||1800;
    const g = c.createGain(); g.gain.value = vol||0.1;
    src.connect(f); f.connect(g); g.connect(c.destination); src.start();
  }

  const api = {
    get muted(){ return muted; },
    toggle(){ muted = !muted; if (muted) api.stopSizzle(); return muted; },
    resume(){ const c = ac(); if (c && c.state==='suspended') c.resume(); },
    click(){ blip(220, 0.05, 'square', 0.08); },
    place(){ blip(180, 0.07, 'square', 0.1, 240); noiseBurst(0.06, 0.05, 1200); },
    add(n){ const f = 340 + (n||0)*36; blip(f, 0.06, 'square', 0.09, f*1.4); noiseBurst(0.04,0.04,1500); },
    flip(){ blip(300, 0.09, 'triangle', 0.1, 520); noiseBurst(0.05,0.05,2500); },
    pull(){ blip(520, 0.08, 'square', 0.1, 700); },
    ding(){ blip(880,0.09,'square',0.11); setTimeout(()=>blip(1320,0.16,'square',0.11),90); },
    cash(){ blip(660,0.07,'square',0.1); setTimeout(()=>blip(990,0.07,'square',0.1),70); setTimeout(()=>blip(1320,0.12,'square',0.1),150); },
    error(){ blip(150,0.18,'sawtooth',0.1,90); },
    burn(){ blip(110,0.3,'sawtooth',0.1,60); noiseBurst(0.3,0.08,700); },
    leave(){ blip(330,0.12,'square',0.1,160); setTimeout(()=>blip(200,0.2,'square',0.1,120),120); },
    trash(){ blip(160,0.09,'square',0.1,80); noiseBurst(0.14,0.09,900); },
    star(){ blip(784,0.08,'square',0.1); setTimeout(()=>blip(1046,0.12,'square',0.1),80); },
    start(){ [523,659,784,1046].forEach((f,i)=>setTimeout(()=>blip(f,0.12,'square',0.1),i*90)); },
    startSizzle(){
      if (muted || sizzleNode) return; const c = ac(); if(!c) return;
      const n = c.sampleRate * 1.5, buf = c.createBuffer(1,n,c.sampleRate), d = buf.getChannelData(0);
      for (let i=0;i<n;i++) d[i]=(Math.random()*2-1);
      const src = c.createBufferSource(); src.buffer=buf; src.loop=true;
      const f = c.createBiquadFilter(); f.type='bandpass'; f.frequency.value=2600; f.Q.value=0.6;
      const g = c.createGain(); g.gain.value=0.0;
      g.gain.linearRampToValueAtTime(0.03, c.currentTime+0.4);
      src.connect(f); f.connect(g); g.connect(c.destination); src.start();
      sizzleNode = src; sizzleGain = g;
    },
    stopSizzle(){
      if (!sizzleNode) return; const c = ac();
      try{ sizzleGain.gain.linearRampToValueAtTime(0.0001, c.currentTime+0.25); sizzleNode.stop(c.currentTime+0.3);}catch(e){}
      sizzleNode = null; sizzleGain = null;
    }
  };
  return api;
})();
