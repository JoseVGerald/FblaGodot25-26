/* ===== BURGER BLITZ — data, sprites, order generation ===== */

// build-station ingredients (patty added separately from grill tray)
const INGREDIENTS = {
  bunBottom: { name: 'Bottom Bun', key: 'Q' },
  cheese:    { name: 'Cheese',     key: '1' },
  lettuce:   { name: 'Lettuce',    key: '2' },
  tomato:    { name: 'Tomato',     key: '3' },
  onion:     { name: 'Onion',      key: '4' },
  pickle:    { name: 'Pickle',     key: '5' },
  ketchup:   { name: 'Ketchup',    key: '6' },
  mustard:   { name: 'Mustard',    key: '7' },
  bunTop:    { name: 'Top Bun',    key: 'E' },
};
// order shown in the bins column
const BIN_ORDER = ['bunBottom','cheese','lettuce','tomato','onion','pickle','ketchup','mustard','bunTop'];
const TOPPING_POOL = ['cheese','lettuce','tomato','onion','pickle','ketchup','mustard'];

// patty doneness <-> cook value (cook accumulates ~16/sec; ~6.5s to burn)
const COOK_MAX = 124;
function donenessFromCook(c){
  if (c < 28)  return 'Raw';
  if (c < 52)  return 'Rare';
  if (c < 78)  return 'Medium';
  if (c < 104) return 'Well';
  return 'Burnt';
}
// colored zones for the cook bar [label, fromPct, color]
const COOK_ZONES = [
  ['Raw',    0,   28,  '#c9b6a0'],
  ['Rare',   28,  52,  '#d8736a'],
  ['Medium', 52,  78,  '#9c5a31'],
  ['Well',   78,  104, '#5e3219'],
  ['Burnt',  104, 124, '#241712'],
];
const DONENESS_COLOR = { Raw:'#b88', Rare:'#c25b50', Medium:'#7a3f22', Well:'#4a2a16', Burnt:'#1c120c' };
function pattyColor(dn){ return DONENESS_COLOR[dn] || '#7a3f22'; }

/* ---------- pixel-art patty sprites ---------- */
const PATTY_PAL = {
  Raw:    { base:'#c0584a', dark:'#94392f', light:'#d98270', edge:'#160b05' },
  Rare:   { base:'#a8503a', dark:'#7a3122', light:'#c47a5e', edge:'#160b05' },
  Medium: { base:'#8a4a28', dark:'#5c2d14', light:'#aa6b3c', edge:'#160b05' },
  Well:   { base:'#5e3219', dark:'#3a1d0b', light:'#7c4c26', edge:'#160b05' },
  Burnt:  { base:'#291a10', dark:'#120a05', light:'#3d2a18', edge:'#0a0503' },
};
function paintPatty(cv, doneness, seed){
  const W = cv.width, H = cv.height;
  const ctx = cv.getContext('2d');
  const pal = PATTY_PAL[doneness] || PATTY_PAL.Medium;
  const r = mulberry(seed || 7);
  ctx.clearRect(0,0,W,H);
  for (let y=0;y<H;y++){
    let inset = 0;
    if (y===0 || y===H-1) inset = 2; else if (y===1 || y===H-2) inset = 1;
    for (let x=inset; x<W-inset; x++){
      let c = pal.base;
      if (y===0 || y===H-1 || x===inset || x===W-1-inset) c = pal.edge;
      else if (y===1) c = pal.light;
      else if (y>=H-2) c = pal.dark;
      else { const rv = r(); if (rv < 0.11) c = pal.dark; else if (rv > 0.93) c = pal.light; }
      ctx.fillStyle = c; ctx.fillRect(x,y,1,1);
    }
  }
  // char/grill marks on cooked patties
  if (doneness !== 'Raw'){
    const marks = 2 + ((r()*3)|0);
    ctx.fillStyle = pal.dark;
    for (let i=0;i<marks;i++){
      const mx = 3+((r()*(W-9))|0), my = 2+((r()*(H-4))|0), len = 2+((r()*3)|0);
      ctx.fillRect(mx,my,len,1);
    }
  }
  cv.dataset.dn = doneness;
}
function pattyCanvas(doneness, sw, sh, px, seed){
  const cv = document.createElement('canvas');
  cv.width = sw; cv.height = sh;
  cv.style.width = (sw*px)+'px'; cv.style.height = (sh*px)+'px';
  cv.style.imageRendering = 'pixelated';
  cv.dataset.seed = seed || ((Math.random()*1e9)|0);
  paintPatty(cv, doneness, +cv.dataset.seed);
  return cv;
}
const DONE_TAG_COLOR = { Rare:'#c25b50', Medium:'#b07a2e', Well:'#4d8a32', Burnt:'#444' };

/* ---------- sprite builder ---------- */
function makeSlab(type, opts){
  opts = opts || {};
  if (type === 'patty'){
    const cv = pattyCanvas(opts.doneness || 'Medium', 52, 7, 4, opts.seed);
    cv.className = 'slab patty' + (opts.icon ? ' icon' : '');
    return cv;
  }
  const el = document.createElement('div');
  el.className = 'slab ' + type + (opts.icon ? ' icon' : '');
  if (type === 'bunTop'){
    const seeds = [[40,18,-20],[95,28,15],[150,16,30],[70,40,5],[125,42,-15],[178,32,12]];
    seeds.forEach(s=>{
      const sd = document.createElement('span'); sd.className='seed';
      sd.style.left = s[0]+'px'; sd.style.top = s[1]+'px';
      sd.style.setProperty('--r', s[2]+'deg');
      el.appendChild(sd);
    });
  }
  if (type === 'pickle'){ for(let i=0;i<5;i++){ el.appendChild(document.createElement('i')); } }
  if (type === 'ketchup' || type === 'mustard'){ el.appendChild(document.createElement('b')); }
  return el;
}
function makeBinIcon(type){
  const box = document.createElement('div'); box.className='iconbox';
  box.appendChild(makeSlab(type, { icon:true, doneness:'Medium' }));
  return box;
}

/* ---------- pixel avatars ---------- */
const SKIN = ['#f2c79b','#e0a875','#c98a55','#a3683c','#7a4a28'];
const HAIR = ['#2a1a0e','#4a2c14','#6b3e1c','#8a5a2a','#b07636','#d9a441','#999','#3a2a4a','#7a2a2a','#2a4a3a'];
const SHIRT = ['#e0463b','#4f8ccc','#6fb24a','#f4c13d','#b76fc4','#e07ba0','#46c0c0','#e88a3c'];
const NAMES = ['Rex','Gabby','Mort','Olive','Buzz','Penny','Hank','Lulu','Dwight','Coco','Sven','Mabel',
  'Tito','Bex','Cliff','Dot','Gus','Vera','Roscoe','Mimi','Wade','Pip','Nash','Trudy'];

// draw a tiny pixel face onto a canvas avatar
function makeAvatar(seed, mood){
  const r = mulberry(seed);
  const sz = 16, scale = 1;
  const cv = document.createElement('canvas'); cv.width = sz; cv.height = sz;
  cv.className = 'avatar';
  cv.style.imageRendering = 'pixelated';
  const x = cv.getContext('2d');
  const skin = SKIN[(r()*SKIN.length)|0];
  const hair = HAIR[(r()*HAIR.length)|0];
  const shirt = SHIRT[(r()*SHIRT.length)|0];
  const bg = ['#cfe3a0','#a0d4e3','#e3c2a0','#e3a0c2','#bfb0e3'][(r()*5)|0];
  x.fillStyle = bg; x.fillRect(0,0,sz,sz);
  // shirt
  x.fillStyle = shirt; x.fillRect(2,13,12,3);
  // head
  x.fillStyle = skin; x.fillRect(4,4,8,9);
  // hair
  x.fillStyle = hair; x.fillRect(3,3,10,3); x.fillRect(3,4,2,5); x.fillRect(11,4,2,5);
  // eyes by mood
  x.fillStyle = '#1a120b';
  if (mood === 'angry'){ x.fillRect(5,7,2,1); x.fillRect(9,7,2,1); x.fillRect(5,6,1,1); x.fillRect(10,6,1,1); }
  else { x.fillRect(5,7,2,2); x.fillRect(9,7,2,2); }
  // mouth
  if (mood === 'happy'){ x.fillRect(6,10,4,1); x.fillRect(5,9,1,1); x.fillRect(10,9,1,1); }
  else if (mood === 'angry'){ x.fillRect(6,11,4,1); x.fillRect(5,10,1,1); x.fillRect(10,10,1,1);
    x.fillStyle = '#cc4b3a'; x.fillRect(13,5,2,3); }
  else { x.fillRect(6,10,4,1); }
  return cv;
}
function mulberry(a){ return function(){ a|=0; a=a+0x6D2B79F5|0; let t=Math.imul(a^a>>>15,1|a);
  t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; }

/* ---------- order generation ---------- */
let _custCounter = 0;
function generateOrder(day){
  const seed = (Date.now() ^ (_custCounter++ * 2654435761)) >>> 0;
  const r = mulberry(seed);
  const items = [{ type:'bunBottom' }];

  const donenessOpts = day >= 2 ? ['Rare','Medium','Well'] : ['Medium','Well'];
  const numPatties = (day >= 2 && r() < 0.35 + day*0.03) ? 2 : 1;

  // choose toppings
  const maxTop = Math.min(2 + day, 5);
  const numTop = 1 + ((r() * maxTop) | 0);
  const pool = TOPPING_POOL.slice();
  const tops = [];
  for (let i=0;i<numTop && pool.length;i++){ tops.push(pool.splice((r()*pool.length)|0,1)[0]); }

  // patties as items
  const patties = [];
  for (let i=0;i<numPatties;i++){ patties.push({ type:'patty', doneness: donenessOpts[(r()*donenessOpts.length)|0] }); }

  // interleave: shuffle (patties + toppings) into a plausible middle
  const middle = patties.concat(tops.map(t=>({type:t})));
  for (let i=middle.length-1;i>0;i--){ const j=(r()*(i+1))|0; [middle[i],middle[j]]=[middle[j],middle[i]]; }
  // keep at least one patty near the bottom for realism: ensure first middle is a patty if possible
  const fp = middle.findIndex(m=>m.type==='patty');
  if (fp > 0){ const p = middle.splice(fp,1)[0]; middle.unshift(p); }

  items.push(...middle, { type:'bunTop' });

  const seed2 = (seed * 16807) >>> 0;
  const nm = NAMES[(mulberry(seed2)()*NAMES.length)|0];
  const basePay = 3 + items.length * 0.6 + numPatties * 0.8;
  const patience = Math.max(20, 42 - day * 2.5); // seconds

  return {
    id: seed,
    name: nm,
    items,
    avatarSeed: seed2,
    basePay: Math.round(basePay * 100) / 100,
    patienceMax: patience,
    patience: patience,
    mood: 'neutral',
  };
}

function fmtMoney(n){ return '$' + (Math.round(n*100)/100).toFixed(2); }
