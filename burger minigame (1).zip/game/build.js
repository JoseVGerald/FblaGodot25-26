/* ===== BURGER BLITZ — BUILD / assembly station ===== */
const Build = (function(){
  let stackEl, binsEl, plateHint;

  function init(){
    stackEl = document.getElementById('stack');
    binsEl = document.getElementById('bins');
    plateHint = document.getElementById('plate-hint');
    renderBins();
    render();
  }

  function reset(){ S.build = []; render(); }

  function addIngredient(type){
    if (S.screen !== 'play' || S.paused) return;
    if (type === 'bunBottom' && S.build.length){ Game.toast('Bottom bun goes first!'); SFX.error(); return; }
    if (S.tab !== 'build') Game.setTab('build');
    S.build.push({ type });
    SFX.add(S.build.length);
    flashBin(type);
    render(true);
  }

  function flashBin(type){
    if (!binsEl) return;
    const bin = binsEl.querySelector('.bin[data-type="' + type + '"]');
    if (bin){ bin.classList.remove('flash'); void bin.offsetWidth; bin.classList.add('flash'); }
  }

  function addPatty(readyIndex){
    if (S.screen !== 'play' || S.paused) return;
    const rp = S.ready[readyIndex];
    if (!rp) return;
    S.build.push({ type:'patty', doneness: rp.doneness, evenSear: rp.evenSear, seed: rp.seed });
    S.ready.splice(readyIndex, 1);
    SFX.add(S.build.length);
    if (S.tab !== 'build') Game.setTab('build');
    Grill.renderTray();
    render(true);
  }

  function undo(){
    if (!S.build.length) return;
    const removed = S.build.pop();
    // return a pulled patty to the tray so it isn't wasted
    if (removed.type === 'patty'){ S.ready.push({ doneness: removed.doneness, evenSear: removed.evenSear, seed: removed.seed }); Grill.renderTray(); }
    SFX.click();
    render();
  }

  function clearPlate(){
    S.build.forEach(b=>{ if(b.type==='patty') S.ready.push({doneness:b.doneness, evenSear:b.evenSear, seed:b.seed}); });
    S.build = [];
    Grill.renderTray();
    SFX.click();
    render();
  }

  const CRUMB_COLORS = { bunBottom:['#e8b465','#cf9341','#fff2cf'], bunTop:['#e8b465','#cf9341','#fff2cf'],
    patty:['#7a3f22','#5c2d14','#3a1d0b'], cheese:['#f4c13d','#ffd75e'], lettuce:['#6fb24a','#9ed06e'],
    tomato:['#d8453b','#ef837a'], onion:['#cda7d6','#efe0f3'], pickle:['#7ba23a','#b8d97a'],
    ketchup:['#e0463b','#ef6a5e'], mustard:['#f4c13d','#ffd75e'] };

  function spawnCrumbs(slabEl, type){
    const wrap = document.getElementById('plate-wrap');
    if (!wrap || !slabEl) return;
    const wr = wrap.getBoundingClientRect(), sr = slabEl.getBoundingClientRect();
    if (!wr.width || !sr.width) return;
    const sx = wr.width ? (1280 / document.getElementById('stage').getBoundingClientRect().width) : 1;
    const colors = CRUMB_COLORS[type] || ['#caa978'];
    for (let i = 0; i < 6; i++){
      const c = document.createElement('span');
      c.className = 'crumb';
      c.style.background = colors[i % colors.length];
      c.style.left = ((sr.left - wr.left + Math.random() * sr.width) * sx) + 'px';
      c.style.top  = ((sr.top - wr.top + sr.height * 0.4) * sx) + 'px';
      c.style.setProperty('--dx', ((Math.random() - 0.5) * 70) + 'px');
      c.style.setProperty('--dy', (-(20 + Math.random() * 45)) + 'px');
      wrap.appendChild(c);
      setTimeout(()=>c.remove(), 480);
    }
  }

  function render(animateTop){
    if (!stackEl) return;
    stackEl.innerHTML = '';
    let topSlab = null, topType = null;
    S.build.forEach((b,i)=>{
      const slab = makeSlab(b.type, { doneness: b.doneness, seed: b.seed });
      if (animateTop && i === S.build.length-1){
        slab.classList.add('dropin'); topSlab = slab; topType = b.type;
        slab.addEventListener('animationend', ()=>slab.classList.remove('dropin'), { once:true });
      }
      stackEl.appendChild(slab);
    });
    if (animateTop && S.build.length){
      stackEl.classList.remove('thud'); void stackEl.offsetWidth; stackEl.classList.add('thud');
      stackEl.addEventListener('animationend', ()=>stackEl.classList.remove('thud'), { once:true });
      requestAnimationFrame(()=>{ setTimeout(()=>spawnCrumbs(topSlab, topType), 110); });
    }
    if (plateHint) plateHint.style.display = S.build.length ? 'none' : 'block';
    // serve enabled only with something on the plate
    const sb = document.getElementById('serve-btn');
    if (sb) sb.disabled = !S.build.length;
    const ub = document.getElementById('undo-btn');
    if (ub) ub.disabled = !S.build.length;
  }

  function renderBins(){
    if (!binsEl) return;
    binsEl.innerHTML = '';
    BIN_ORDER.forEach(type=>{
      const ing = INGREDIENTS[type];
      const bin = document.createElement('div');
      bin.className = 'bin';
      bin.dataset.type = type;
      const key = document.createElement('span'); key.className='key'; key.textContent = ing.key;
      const ic = makeBinIcon(type);
      const nm = document.createElement('span'); nm.className='nm'; nm.textContent = ing.name;
      bin.appendChild(key); bin.appendChild(ic); bin.appendChild(nm);
      bin.onclick = ()=> addIngredient(type);
      binsEl.appendChild(bin);
    });
  }

  function serve(){
    if (!S.build.length) return;
    Game.serveOrder();
  }

  return { init, reset, addIngredient, addPatty, undo, clearPlate, render, serve };
})();
