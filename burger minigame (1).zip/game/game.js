/* ===== BURGER BLITZ — game controller ===== */
const S = {
  screen:'title', paused:false, tab:'grill', trashMode:false,
  day:1, money:0, score:0,
  dayLength:95, dayTimeLeft:95,
  dayCustomers:5, spawnedCount:0, spawnInterval:8, spawnTimer:0,
  queue:[], grill:[null,null,null,null], ready:[], build:[],
  dayServed:0, dayMissed:0, dayEarnings:0, dayStars:0, dayPerfect:0,
};

const SWATCH = { bunBottom:'#e8b465', bunTop:'#e8b465', patty:'#7a3f22', cheese:'#f4c13d',
  lettuce:'#6fb24a', tomato:'#d8453b', onion:'#cda7d6', pickle:'#7ba23a', ketchup:'#e0463b', mustard:'#f4c13d' };
const el = id => document.getElementById(id);
function labelOf(type){ return type === 'patty' ? 'Patty' : (INGREDIENTS[type] ? INGREDIENTS[type].name : type); }
function loadNum(k,d){ const v=parseFloat(localStorage.getItem(k)); return isNaN(v)?d:v; }
function saveNum(k,v){ try{ localStorage.setItem(k, String(v)); }catch(e){} }

const Game = {
  /* ---------- screens ---------- */
  showScreen(name){
    S.screen = name;
    document.querySelectorAll('.screen').forEach(s=>s.classList.toggle('active', s.id === 'screen-'+name));
  },

  /* ---------- trash mode ---------- */
  toggleTrash(force){
    S.trashMode = (force !== undefined) ? force : !S.trashMode;
    el('trash-btn').classList.toggle('armed', S.trashMode);
    el('ready-grid').classList.toggle('trashing', S.trashMode);
    SFX.click();
    if (S.trashMode) Game.toast('TRASH MODE — click a tray patty to bin it');
  },

  /* ---------- station tabs ---------- */
  setTab(name){
    S.tab = name;
    el('tab-grill').classList.toggle('active', name === 'grill');
    el('tab-build').classList.toggle('active', name === 'build');
    el('grill-panel').classList.toggle('hidden', name !== 'grill');
    el('build-panel').classList.toggle('hidden', name !== 'build');
    if (name === 'grill') el('tab-grill').classList.remove('alert');
    SFX.click();
  },

  startRun(){
    SFX.resume();
    S.day = 1; S.money = 0; S.score = 0;
    Game.startDay();
  },

  startDay(){
    S.paused = false;
    S.dayLength = 95;
    S.dayTimeLeft = S.dayLength;
    S.dayCustomers = 4 + S.day;
    S.spawnedCount = 0;
    S.spawnInterval = Math.max(5.5, 8 - S.day * 0.3);
    S.spawnTimer = 0;
    S.queue = [];
    S.dayServed = 0; S.dayMissed = 0; S.dayEarnings = 0; S.dayStars = 0; S.dayPerfect = 0;
    Grill.reset(); Build.reset();
    Game.toggleTrash(false);
    Game.setTab('grill');
    Game.showScreen('play');
    const banner = el('day-banner'); banner.textContent = 'DAY ' + S.day;
    banner.classList.remove('show'); void banner.offsetWidth; banner.classList.add('show');
    Game.spawnCustomer();
    Game.renderActiveOrder();
    Game.updateHud();
    SFX.start();
  },

  nextDay(){ S.day++; Game.startDay(); },
  toTitle(){ S.paused = true; SFX.stopSizzle(); Game.refreshTitle(); Game.showScreen('title'); },

  /* ---------- customers ---------- */
  spawnCustomer(){
    if (S.spawnedCount >= S.dayCustomers) return;
    const o = generateOrder(S.day);
    S.queue.push(o);
    S.spawnedCount++;
    S.spawnTimer = S.spawnInterval;
    if (S.queue.length === 1) Game.renderActiveOrder();
    else Game.renderQueueStrip();
  },

  renderActiveOrder(){
    const order = S.queue[0];
    const custBox = el('cust-box'), ticketBox = el('ticket-box');
    if (!order){
      custBox.innerHTML = '<div class="cust-name" style="padding:12px;color:#9a865f">Waiting for customer\u2026</div>';
      ticketBox.innerHTML = '';
      Game.renderQueueStrip();
      return;
    }
    custBox.innerHTML = '';
    const av = makeAvatar(order.avatarSeed, order.mood);
    custBox.appendChild(av);
    const meta = document.createElement('div'); meta.className = 'cust-meta';
    const nm = document.createElement('div'); nm.className = 'cust-name'; nm.textContent = order.name;
    const pat = document.createElement('div'); pat.className = 'patience'; pat.id = 'patience-bar';
    pat.appendChild(document.createElement('i'));
    meta.appendChild(nm); meta.appendChild(pat);
    custBox.appendChild(meta);

    ticketBox.innerHTML = '';
    const tk = document.createElement('div'); tk.className = 'ticket';
    const ol = document.createElement('ol');
    order.items.forEach(it=>{
      const li = document.createElement('li');
      const dot = document.createElement('span'); dot.className = 'dot'; dot.style.background = SWATCH[it.type] || '#999';
      const nm2 = document.createElement('span'); nm2.textContent = labelOf(it.type);
      li.appendChild(dot); li.appendChild(nm2);
      if (it.type === 'patty'){
        const dt = document.createElement('span'); dt.className = 'done-tag';
        dt.textContent = it.doneness; dt.style.background = DONE_TAG_COLOR[it.doneness] || '#666';
        li.appendChild(dt);
      }
      ol.appendChild(li);
    });
    tk.appendChild(ol); ticketBox.appendChild(tk);
    Game.renderQueueStrip();
  },

  renderQueueStrip(){
    const strip = el('queue-strip'); if(!strip) return;
    strip.innerHTML = '';
    const waiting = S.queue.slice(1, 4);
    waiting.forEach(o=>{ const m = makeAvatar(o.avatarSeed, 'neutral'); m.className = 'mini'; strip.appendChild(m); });
    const remaining = S.dayCustomers - S.spawnedCount + Math.max(0, S.queue.length - 4);
    if (remaining > 0){ const more = document.createElement('span'); more.className = 'more'; more.textContent = '+' + remaining; strip.appendChild(more); }
  },

  customerLeaves(){
    const order = S.queue[0]; if(!order || order.resolved) return;
    order.resolved = true;
    S.dayMissed++;
    SFX.leave();
    Game.reactAvatar('angry');
    Game.float('LEFT! \uD83D\uDE21', '#b22f27');
    Game.toast(order.name + ' stormed off!');
    Build.clearPlate();
    setTimeout(()=>{ S.queue.shift(); Game.afterResolve(); }, 500);
  },

  afterResolve(){
    if (S.queue.length === 0 && S.spawnedCount < S.dayCustomers) S.spawnTimer = Math.min(S.spawnTimer, 0.7);
    Game.renderActiveOrder();
    Game.checkDayEnd();
  },

  /* ---------- serving / scoring ---------- */
  serveOrder(){
    const order = S.queue[0];
    if (!order || order.resolved) return;
    order.resolved = true;
    const res = Game.scoreBuild(S.build, order);

    let pay = Math.max(0, order.basePay * res.overall), tip = 0;
    if (res.stars === 3) tip = order.basePay * 0.5 + (order.patience / order.patienceMax) * 2.0;
    else if (res.stars === 2) tip = order.basePay * 0.2;
    pay = Math.round((pay + Math.max(0, tip)) * 100) / 100;

    S.money += pay; S.dayEarnings += pay; S.score += res.points;
    S.dayServed++; S.dayStars += res.stars; if (res.stars === 3) S.dayPerfect++;

    Game.reactAvatar(res.mood);
    Game.float((pay > 0 ? '+' : '') + fmtMoney(pay), pay > 0 ? '#3a7a26' : '#b22f27');
    Game.toast(res.label + '   ' + '\u2605'.repeat(res.stars) + '\u2606'.repeat(3 - res.stars));
    if (res.stars >= 2){ SFX.ding(); setTimeout(()=>SFX.cash(), 220); }
    else if (res.stars === 1){ SFX.cash(); }
    else { SFX.error(); }

    S.build = []; Build.render();
    setTimeout(()=>{ S.queue.shift(); Game.afterResolve(); }, 520);
  },

  scoreBuild(build, order){
    const want = order.items, got = build;
    const L = Math.max(want.length, got.length);
    let correct = 0;
    for (let i=0;i<L;i++){ const w = want[i], g = got[i]; if (w && g && w.type === g.type) correct++; }
    const itemScore = want.length ? correct / L : 0;

    let pWant = 0, pRight = 0;
    for (let i=0;i<want.length;i++){
      if (want[i].type === 'patty'){ pWant++;
        const g = got[i];
        if (g && g.type === 'patty' && g.doneness === want[i].doneness) pRight++;
      }
    }
    const doneScore = pWant ? pRight / pWant : 1;
    const overall = itemScore * 0.72 + doneScore * 0.28;
    let stars, label, mood;
    if (overall >= 0.965){ stars = 3; label = 'PERFECT!'; mood = 'happy'; }
    else if (overall >= 0.8){ stars = 2; label = 'GREAT'; mood = 'happy'; }
    else if (overall >= 0.55){ stars = 1; label = 'OKAY'; mood = 'neutral'; }
    else { stars = 0; label = 'WRONG ORDER'; mood = 'angry'; }
    const points = Math.round(overall * 100) + stars * 25;
    return { overall, stars, label, mood, points };
  },

  reactAvatar(mood){
    const order = S.queue[0]; if(!order) return;
    order.mood = mood;
    const box = el('cust-box'); const old = box.querySelector('canvas');
    if (old){ const av = makeAvatar(order.avatarSeed, mood); av.classList.add('pop'); box.replaceChild(av, old); }
  },

  /* ---------- day flow ---------- */
  checkDayEnd(){
    if (S.spawnedCount >= S.dayCustomers && S.queue.length === 0 && S.screen === 'play') Game.endDay('clear');
  },

  endDay(reason){
    if (S.screen !== 'play') return;
    S.paused = true; SFX.stopSizzle();
    const best = Math.max(loadNum('bb_best', 0), S.dayEarnings);
    saveNum('bb_best', best);
    saveNum('bb_total', loadNum('bb_total', 0) + S.dayEarnings);

    const total = S.dayServed + S.dayMissed;
    const acc = total ? Math.round(S.dayStars / (total * 3) * 100) : 0;
    el('result-head').textContent = (reason === 'time' ? "TIME'S UP!" : 'DAY ' + S.day + ' DONE');
    el('result-body').innerHTML = `
      <div class="stat-row"><span>Burgers served</span><span class="v green">${S.dayServed}</span></div>
      <div class="stat-row"><span>Customers lost</span><span class="v ${S.dayMissed?'red':''}">${S.dayMissed}</span></div>
      <div class="stat-row"><span>Perfect orders</span><span class="v">${S.dayPerfect} \u2605</span></div>
      <div class="stat-row"><span>Kitchen rating</span><span class="v">${acc}%</span></div>
      <div class="stat-row"><span>Today's earnings</span><span class="v green">${fmtMoney(S.dayEarnings)}</span></div>
      <div class="stat-row"><span>Best day ever</span><span class="v">${fmtMoney(best)}</span></div>`;
    Game.showScreen('result');
    SFX.star();
  },

  /* ---------- feedback ---------- */
  toast(msg){
    const t = document.createElement('div'); t.className = 'toast'; t.textContent = msg;
    el('stage').appendChild(t);
    setTimeout(()=>t.remove(), 1900);
  },
  float(text, color){
    const f = document.createElement('div'); f.className = 'float'; f.textContent = text;
    f.style.color = color || '#fff';
    const anchor = el('plate-wrap').getBoundingClientRect();
    const stage = el('stage').getBoundingClientRect();
    const scale = stage.width / 1280;
    f.style.left = ((anchor.left - stage.left) / scale + 90) + 'px';
    f.style.top = ((anchor.top - stage.top) / scale + 30) + 'px';
    el('stage').appendChild(f);
    setTimeout(()=>f.remove(), 1100);
  },

  refreshTitle(){
    el('hi-best').textContent = fmtMoney(loadNum('bb_best', 0));
  },

  /* ---------- loop ---------- */
  _last: 0,
  loop(t){
    if (!Game._last) Game._last = t;
    let dt = (t - Game._last) / 1000; Game._last = t;
    if (dt > 0.1) dt = 0.1;
    if (S.screen === 'play' && !S.paused){
      S.dayTimeLeft -= dt;
      const cust = S.queue[0];
      if (cust && !cust.resolved){ cust.patience -= dt; if (cust.patience <= 0) Game.customerLeaves(); }
      S.spawnTimer -= dt;
      if (S.spawnedCount < S.dayCustomers && S.queue.length < 3 && S.spawnTimer <= 0) Game.spawnCustomer();
      Grill.update(dt);
      Game.updateHud();
      if (S.dayTimeLeft <= 0) Game.endDay('time');
    }
    requestAnimationFrame(Game.loop);
  },

  updateHud(){
    el('hud-day').querySelector('.val').textContent = S.day;
    el('hud-time').querySelector('.val').textContent = Math.max(0, Math.ceil(S.dayTimeLeft));
    el('hud-cust').querySelector('.val').textContent = (S.dayServed + S.dayMissed) + '/' + S.dayCustomers;
    el('hud-score').querySelector('.val').textContent = S.score;
    el('hud-money').querySelector('.val').textContent = fmtMoney(S.money);
    const frac = Math.max(0, S.dayTimeLeft) / S.dayLength;
    const bar = el('day-bar'); bar.querySelector('i').style.width = (frac * 100) + '%';
    bar.classList.toggle('warn', frac < 0.25);
    const order = S.queue[0]; const pb = document.getElementById('patience-bar');
    if (pb && order){ const pf = Math.max(0, order.patience / order.patienceMax);
      pb.querySelector('i').style.transform = 'scaleX(' + pf + ')';
      pb.classList.toggle('mid', pf < 0.5); pb.classList.toggle('low', pf < 0.25);
    }
  },

  /* ---------- layout ---------- */
  fit(){
    const s = Math.min(window.innerWidth / 1280, window.innerHeight / 720);
    el('stage').style.transform = 'scale(' + s + ')';
  },
};

/* ---------- input ---------- */
function bindInput(){
  el('btn-start').onclick = ()=>{ SFX.resume(); SFX.click(); Game.startRun(); };
  el('screen-title').addEventListener('click', e=>{ if (e.target.id !== 'btn-mute') { /* allow mute */ } });
  el('btn-add-patty').onclick = ()=>{ SFX.resume(); Grill.addPatty(); };
  el('tab-grill').onclick = ()=> Game.setTab('grill');
  el('tab-build').onclick = ()=> Game.setTab('build');
  el('trash-btn').onclick = ()=> Game.toggleTrash();
  el('serve-btn').onclick = ()=> Build.serve();
  el('undo-btn').onclick = ()=> Build.undo();
  el('clear-btn').onclick = ()=> Build.clearPlate();
  el('next-day-btn').onclick = ()=>{ SFX.click(); Game.nextDay(); };
  el('quit-btn').onclick = ()=>{ SFX.click(); Game.toTitle(); };

  function toggleMute(){ const m = SFX.toggle(); saveNum('bb_muted', m?1:0);
    document.querySelectorAll('.mute-btn').forEach(b=> b.textContent = m ? '\uD83D\uDD07 OFF' : '\uD83D\uDD0A ON'); }
  document.querySelectorAll('.mute-btn').forEach(b=> b.onclick = (e)=>{ e.stopPropagation(); toggleMute(); });

  const crtBtn = el('crt-btn');
  crtBtn.onclick = (e)=>{ e.stopPropagation(); el('crt').classList.toggle('off');
    crtBtn.textContent = el('crt').classList.contains('off') ? 'CRT OFF' : 'CRT ON'; };

  window.addEventListener('keydown', e=>{
    if (S.screen === 'title' && (e.key === ' ' || e.key === 'Enter')){ e.preventDefault(); SFX.resume(); Game.startRun(); return; }
    if (S.screen === 'result' && (e.key === ' ' || e.key === 'Enter')){ e.preventDefault(); Game.nextDay(); return; }
    if (S.screen !== 'play') return;
    const k = e.key.toLowerCase();
    if (k === 'tab'){ e.preventDefault(); Game.setTab(S.tab === 'grill' ? 'build' : 'grill'); return; }
    if (k === 'g'){ Game.setTab('grill'); return; }
    if (k === 'b'){ Game.setTab('build'); return; }
    if (k === 't'){ Game.toggleTrash(); return; }
    if (k === ' '){ e.preventDefault(); Build.serve(); return; }
    if (k === 'backspace' || k === 'u'){ e.preventDefault(); Build.undo(); return; }
    if (k === 'a'){ e.preventDefault(); Grill.addPatty(); return; }
    if (k === 'q'){ Build.addIngredient('bunBottom'); return; }
    if (k === 'e'){ Build.addIngredient('bunTop'); return; }
    const map = { '1':'cheese','2':'lettuce','3':'tomato','4':'onion','5':'pickle','6':'ketchup','7':'mustard' };
    if (map[e.key]){ Build.addIngredient(map[e.key]); }
  });

  window.addEventListener('resize', Game.fit);
}

/* ---------- boot ---------- */
window.addEventListener('DOMContentLoaded', ()=>{
  Grill.init(); Build.init(); bindInput();
  if (loadNum('bb_muted', 0)){ SFX.toggle(); document.querySelectorAll('.mute-btn').forEach(b=> b.textContent = '\uD83D\uDD07 OFF'); }
  Game.refreshTitle();
  Game.fit();
  Game.showScreen('title');
  requestAnimationFrame(Game.loop);
});
