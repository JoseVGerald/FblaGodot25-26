/* ===== BURGER BLITZ — GRILL station ===== */
const Grill = (function(){
  const SLOTS = 4;
  let surfaceEl, trayEl;

  function init(){
    surfaceEl = document.getElementById('grill-surface');
    trayEl = document.getElementById('ready-grid');
    renderSlots();
    renderTray();
  }

  function reset(){
    S.grill = [null,null,null,null];
    S.ready = [];
    renderSlots(); renderTray();
    SFX.stopSizzle();
  }

  function freeSlot(){ return S.grill.findIndex(g=>g===null); }

  function addPatty(){
    const i = freeSlot();
    if (i < 0){ Game.toast('Grill is full!'); SFX.error(); return; }
    if (S.tab !== 'grill') Game.setTab('grill');
    S.grill[i] = { cook:0, flipped:false, evenSear:false, removed:false, seed:(Math.random()*1e9)|0 };
    SFX.place(); SFX.startSizzle();
    renderSlots();
  }

  function flip(i){
    const p = S.grill[i]; if(!p) return;
    p.flipped = true;
    // a good sear: flip while in the 40–78 cook window
    if (p.cook >= 40 && p.cook <= 80) p.evenSear = true;
    SFX.flip();
    const el = surfaceEl.children[i];
    if (el){ const patty = el.querySelector('.gpatty'); if(patty){ patty.classList.remove('flipanim'); void patty.offsetWidth; patty.classList.add('flipanim'); } }
  }

  function pull(i){
    const p = S.grill[i]; if(!p) return;
    const dn = donenessFromCook(p.cook);
    if (dn === 'Raw'){ Game.toast('Too raw!'); SFX.error(); return; }
    S.ready.push({ doneness: dn, evenSear: p.evenSear, seed: p.seed });
    S.grill[i] = null;
    if (dn === 'Burnt') SFX.burn(); else SFX.pull();
    if (!S.grill.some(Boolean)) SFX.stopSizzle();
    renderSlots(); renderTray();
  }

  function trashSlot(i){
    if (!S.grill[i]) return;
    S.grill[i] = null;
    SFX.trash();
    if (!S.grill.some(Boolean)) SFX.stopSizzle();
    renderSlots();
  }

  function trashReady(idx){
    if (!S.ready[idx]) return;
    S.ready.splice(idx, 1);
    SFX.trash();
    renderTray();
  }

  // called every frame from the game loop
  function update(dt){
    if (S.screen !== 'play' || S.paused) return;
    let anyCooking = false, danger = false;
    for (let i=0;i<SLOTS;i++){
      const p = S.grill[i];
      if (!p) continue;
      anyCooking = true;
      p.cook = Math.min(COOK_MAX, p.cook + dt * 16);
      if (p.cook >= 96) danger = true;
      const el = surfaceEl.children[i];
      if (el) updateSlotLive(el, p, i);
    }
    if (!anyCooking) SFX.stopSizzle();
    // flash the grill tab if something is about to burn while you're assembling
    const tab = document.getElementById('tab-grill');
    if (tab) tab.classList.toggle('alert', danger && S.tab !== 'grill');
  }

  function updateSlotLive(el, p, i){
    const dn = donenessFromCook(p.cook);
    const patty = el.querySelector('.gpatty');
    if (patty && patty.dataset.dn !== dn) paintPatty(patty, dn, p.seed);
    const needle = el.querySelector('.needle');
    if (needle) needle.style.left = (p.cook / COOK_MAX * 100) + '%';
    const lbl = el.querySelector('.cooklabel');
    if (lbl) lbl.textContent = dn.toUpperCase();
    const pullBtn = el.querySelector('.mini-btn.pull');
    if (pullBtn) pullBtn.disabled = (dn === 'Raw');
    // burnt warning flash
    if (dn === 'Burnt') el.classList.add('burning'); else el.classList.remove('burning');
  }

  function renderSlots(){
    if (!surfaceEl) return;
    surfaceEl.innerHTML = '';
    for (let i=0;i<SLOTS;i++){
      const p = S.grill[i];
      const slot = document.createElement('div');
      slot.className = 'gslot' + (p ? ' full' : '');
      if (!p){
        slot.innerHTML = '<span style="opacity:.6">empty</span>';
      } else {
        const dn = donenessFromCook(p.cook);
        const patty = pattyCanvas(dn, 27, 9, 5, p.seed);
        patty.className = 'gpatty sizzle' + (p.flipped ? ' flipped':'');
        slot.appendChild(patty);

        const bar = document.createElement('div'); bar.className = 'cookbar';
        const zones = document.createElement('div'); zones.className = 'zones';
        COOK_ZONES.forEach(z=>{
          const s = document.createElement('span');
          s.style.width = ((z[2]-z[1]) / COOK_MAX * 100) + '%';
          s.style.background = z[3];
          zones.appendChild(s);
        });
        bar.appendChild(zones);
        const needle = document.createElement('div'); needle.className='needle';
        needle.style.left = (p.cook / COOK_MAX * 100) + '%';
        bar.appendChild(needle);
        slot.appendChild(bar);

        const lbl = document.createElement('div'); lbl.className='cooklabel'; lbl.textContent = dn.toUpperCase();
        slot.appendChild(lbl);

        const btns = document.createElement('div'); btns.className='gbtns';
        const fb = document.createElement('button'); fb.className='mini-btn'; fb.textContent = p.flipped?'FLIP\u2713':'FLIP';
        fb.onclick = ()=>flip(i);
        const pb = document.createElement('button'); pb.className='mini-btn pull'; pb.textContent='PULL';
        pb.disabled = (dn === 'Raw');
        pb.onclick = ()=>pull(i);
        const tb = document.createElement('button'); tb.className='mini-btn trash'; tb.textContent='\u2715';
        tb.title = 'Trash this patty';
        tb.onclick = ()=>trashSlot(i);
        btns.appendChild(fb); btns.appendChild(pb); btns.appendChild(tb);
        slot.appendChild(btns);
      }
      surfaceEl.appendChild(slot);
    }
  }

  function renderTray(){
    if (!trayEl) return;
    trayEl.innerHTML = '';
    if (!S.ready.length){
      trayEl.innerHTML = '<span class="tray-empty">cooked patties land here \u2192 click to stack</span>';
      return;
    }
    S.ready.forEach((rp, idx)=>{
      const el = document.createElement('div');
      el.className = 'ready-patty';
      el.title = 'Add ' + rp.doneness + ' patty to burger';
      const cv = pattyCanvas(rp.doneness, 18, 8, 4, rp.seed);
      el.appendChild(cv);
      const dn = document.createElement('span'); dn.className='dn'; dn.textContent = rp.doneness.toUpperCase();
      el.appendChild(dn);
      el.onclick = ()=>{ if (S.trashMode) trashReady(idx); else Build.addPatty(idx); };
      el.oncontextmenu = (e)=>{ e.preventDefault(); trashReady(idx); };
      trayEl.appendChild(el);
    });
  }

  return { init, reset, addPatty, flip, pull, trashSlot, trashReady, update, renderSlots, renderTray };
})();
