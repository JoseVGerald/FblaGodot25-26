/* ===== BANK BLITZ — data, applicants, lending policy ===== */

/* ---------- RNG + pixel avatars (townsfolk NPCs) ---------- */
function mulberry(a){ return function(){ a|=0; a=a+0x6D2B79F5|0; let t=Math.imul(a^a>>>15,1|a);
  t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; }

const SKIN = ['#f2c79b','#e0a875','#c98a55','#a3683c','#7a4a28'];
const HAIR = ['#2a1a0e','#4a2c14','#6b3e1c','#8a5a2a','#b07636','#d9a441','#aaa','#3a2a4a','#7a2a2a','#2a4a3a'];
const SHIRT = ['#d8483b','#4f8ccc','#3fa45a','#f2c23d','#b76fc4','#e07ba0','#46c0c0','#e88a3c'];

// townspeople you'd meet in a game world: name + occupation
const TOWNSFOLK = [
  ['Mabel','Baker'],['Gus','Blacksmith'],['Pearl','Seamstress'],['Sven','Fisherman'],
  ['Otto','Carpenter'],['Rosa','Innkeeper'],['Cliff','Miner'],['Hazel','Teacher'],
  ['Bram','Farmer'],['Trudy','Herbalist'],['Wade','Sailor'],['Ida','Potter'],
  ['Nash','Rancher'],['Vera','Tailor'],['Roscoe','Butcher'],['Coraline','Florist'],
  ['Dwight','Locksmith'],['Pip','Courier'],['Mort','Gravedigger'],['Olive','Beekeeper'],
  ['Hank','Brewer'],['Lulu','Weaver'],['Tito','Cobbler'],['Bex','Mapmaker'],
];

function makeAvatar(seed, mood){
  const r = mulberry(seed);
  const sz = 16;
  const cv = document.createElement('canvas'); cv.width = sz; cv.height = sz;
  cv.className = 'avatar'; cv.style.imageRendering = 'pixelated';
  const x = cv.getContext('2d');
  const skin = SKIN[(r()*SKIN.length)|0], hair = HAIR[(r()*HAIR.length)|0], shirt = SHIRT[(r()*SHIRT.length)|0];
  const bg = ['#cfe3a0','#a0d4e3','#e3c2a0','#e3a0c2','#bfb0e3'][(r()*5)|0];
  x.fillStyle = bg; x.fillRect(0,0,sz,sz);
  x.fillStyle = shirt; x.fillRect(2,13,12,3);
  x.fillStyle = skin; x.fillRect(4,4,8,9);
  x.fillStyle = hair; x.fillRect(3,3,10,3); x.fillRect(3,4,2,5); x.fillRect(11,4,2,5);
  x.fillStyle = '#1a120b';
  if (mood === 'angry'){ x.fillRect(5,7,2,1); x.fillRect(9,7,2,1); x.fillRect(5,6,1,1); x.fillRect(10,6,1,1); }
  else { x.fillRect(5,7,2,2); x.fillRect(9,7,2,2); }
  if (mood === 'happy'){ x.fillRect(6,10,4,1); x.fillRect(5,9,1,1); x.fillRect(10,9,1,1); }
  else if (mood === 'angry'){ x.fillRect(6,11,4,1); x.fillRect(5,10,1,1); x.fillRect(10,10,1,1);
    x.fillStyle = '#cc4b3a'; x.fillRect(13,5,2,3); }
  else { x.fillRect(6,10,4,1); }
  return cv;
}

/* ---------- loan purposes ---------- */
// productive purposes the bank funds
const GOOD_PURPOSES = [
  'Open a bakery','Buy a fishing boat','Repair the roof','Cover medical bills',
  'Pay tuition','Buy a delivery cart','Expand the farm','New blacksmith forge',
  'Restock the shop','Consolidate old debt','Buy seed & livestock','Open a tailor stall',
];
// speculative purposes policy prohibits
const BANNED_PURPOSES = [
  'Bet on the horse races','Buy lottery tickets','Invest in sea-monster coins',
  'Fund a get-rich scheme','High-stakes card game','Speculate on tulip bulbs',
];
const COLLATERAL_ITEMS = ['Horse & cart','Workshop tools','Farmland deed','Fishing boat','Family jewelry','Shop inventory','Timber lot'];

/* ---------- the bank's lending policy (ground truth) ---------- */
// All thresholds are shown to the player in the POLICY tab.
const POLICY = { maxDTI: 0.40, minCredit: 600 };

function evalRisk(app){
  const dtiAfter = (app.debt + app.payment) / app.income;
  app.dtiAfter = dtiAfter;
  app.secured = app.collateralValue >= app.amount;
  const reasons = [];
  let risky = false;
  if (dtiAfter > POLICY.maxDTI){ risky = true; reasons.push('Debt load too high (DTI ' + Math.round(dtiAfter*100) + '% > 40%)'); }
  if (app.creditScore < POLICY.minCredit && !app.secured){ risky = true; reasons.push('Credit ' + app.creditScore + ' under 600 and loan is unsecured'); }
  if (app.purposeBanned){ risky = true; reasons.push('Prohibited purpose (speculation/gambling)'); }
  app.risky = risky;
  app.reasons = reasons;
  app.correct = risky ? 'deny' : 'approve';   // the right call
  return app;
}

/* ---------- application generation ---------- */
let _appCounter = 0;
function generateApplication(day){
  const seed = (Date.now() ^ (_appCounter++ * 2654435761)) >>> 0;
  const r = mulberry(seed);
  const seed2 = (seed * 16807) >>> 0;
  const rr = mulberry(seed2);

  const who = TOWNSFOLK[(r()*TOWNSFOLK.length)|0];

  const income = 1500 + Math.round((r()*5500)/50)*50;          // 1,500 – 7,000 / mo
  const terms = [12,24,36,48,60];
  const term = terms[(r()*terms.length)|0];
  let amount = 2000 + Math.round((r()*16000)/100)*100;         // 2,000 – 18,000
  let payment = Math.round(amount / term);
  let debt = Math.round(income * (0.05 + r()*0.38) / 10) * 10; // existing monthly debt

  let credit = 540 + ((r()*260)|0);                            // 540 – 800

  // purpose (banned chance climbs with day)
  const bannedChance = Math.min(0.42, 0.12 + day*0.045);
  let purpose, purposeBanned;
  if (rr() < bannedChance){ purpose = BANNED_PURPOSES[(rr()*BANNED_PURPOSES.length)|0]; purposeBanned = true; }
  else { purpose = GOOD_PURPOSES[(rr()*GOOD_PURPOSES.length)|0]; purposeBanned = false; }

  // collateral
  let collateral = null, collateralValue = 0;
  if (rr() < 0.5){
    collateralValue = Math.round(amount * (0.25 + rr()*1.0) / 100) * 100;
    collateral = { label: COLLATERAL_ITEMS[(rr()*COLLATERAL_ITEMS.length)|0], value: collateralValue };
  }

  // later days: push values toward the thresholds to force careful reads
  if (day >= 2){
    if (r() < 0.45){
      const T = 0.40 + (rr()-0.5)*0.07;           // target DTI 0.365–0.435
      debt = Math.max(0, Math.round((T*income - payment)/10)*10);
    }
    if (r() < 0.4){ credit = 584 + ((rr()*32)|0); } // 584–616, near the 600 line
  }

  const app = {
    id: seed, name: who[0], occupation: who[1], avatarSeed: seed2,
    income, debt, amount, term, payment, creditScore: credit,
    purpose, purposeBanned, collateral, collateralValue,
    patienceMax: Math.max(15, 32 - day*1.8), patience: 0, mood: 'neutral', resolved: false,
  };
  app.patience = app.patienceMax;
  return evalRisk(app);
}

/* ---------- money formatting ---------- */
function fmtMoney(n){
  const neg = n < 0; n = Math.abs(Math.round(n));
  let s = String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return (neg ? '-$' : '$') + s;
}
function fmtPct(f){ return Math.round(f*100) + '%'; }
