/* ===== BANK BLITZ — retro WebAudio SFX ===== */
const SFX = (function(){
  let ctx = null, muted = false;
  function ac(){ if(!ctx){ try{ ctx = new (window.AudioContext||window.webkitAudioContext)(); }catch(e){} } return ctx; }
  function blip(freq, dur, type, vol, slideTo){
    if (muted) return; const c = ac(); if(!c) return;
    const o = c.createOscillator(), g = c.createGain();
    o.type = type||'square'; o.frequency.value = freq;
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, c.currentTime+dur);
    g.gain.value = vol||0.12; g.gain.setValueAtTime(g.gain.value, c.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime+dur);
    o.connect(g); g.connect(c.destination); o.start(); o.stop(c.currentTime+dur);
  }
  function noise(dur, vol, lp){
    if (muted) return; const c = ac(); if(!c) return;
    const n = c.sampleRate*dur, buf = c.createBuffer(1,n,c.sampleRate), d = buf.getChannelData(0);
    for (let i=0;i<n;i++) d[i] = (Math.random()*2-1)*(1-i/n);
    const src = c.createBufferSource(); src.buffer = buf;
    const f = c.createBiquadFilter(); f.type='lowpass'; f.frequency.value = lp||1600;
    const g = c.createGain(); g.gain.value = vol||0.1;
    src.connect(f); f.connect(g); g.connect(c.destination); src.start();
  }
  const api = {
    get muted(){ return muted; },
    toggle(){ muted = !muted; return muted; },
    resume(){ const c = ac(); if (c && c.state==='suspended') c.resume(); },
    click(){ blip(220,0.05,'square',0.08); },
    tab(){ blip(330,0.05,'square',0.07,420); },
    stampApprove(){ noise(0.09,0.16,900); blip(150,0.09,'square',0.12,90); setTimeout(()=>{ blip(740,0.07,'square',0.1); setTimeout(()=>blip(1100,0.13,'square',0.1),70); },90); },
    stampDeny(){ noise(0.09,0.16,800); blip(150,0.09,'square',0.12,80); setTimeout(()=>blip(180,0.22,'sawtooth',0.1,110),90); },
    good(){ blip(660,0.07,'square',0.1); setTimeout(()=>blip(990,0.07,'square',0.1),70); setTimeout(()=>blip(1320,0.12,'square',0.1),150); },
    coin(){ blip(988,0.06,'square',0.1); setTimeout(()=>blip(1319,0.1,'square',0.1),70); },
    bad(){ blip(300,0.14,'sawtooth',0.11,150); setTimeout(()=>blip(160,0.3,'sawtooth',0.11,80),130); },
    error(){ blip(150,0.18,'sawtooth',0.1,90); },
    leave(){ blip(330,0.12,'square',0.1,160); setTimeout(()=>blip(200,0.2,'square',0.1,120),120); },
    star(){ blip(784,0.08,'square',0.1); setTimeout(()=>blip(1046,0.12,'square',0.1),80); },
    over(){ [440,392,330,262].forEach((f,i)=>setTimeout(()=>blip(f,0.25,'sawtooth',0.1),i*180)); },
    start(){ [523,659,784,1046].forEach((f,i)=>setTimeout(()=>blip(f,0.12,'square',0.1),i*90)); },
  };
  return api;
})();
