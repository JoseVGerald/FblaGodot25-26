/* ===== BANK BLITZ — Loan Decision Desk controller ===== */
const S = {
  screen:'title', paused:false, helpOpen:false,
  day:1, capital:6000, score:0, streak:0,
  dayLength:100, dayTimeLeft:100,
  dayApplicants:6, spawnedCount:0, spawnInterval:7, spawnTimer:0,
  queue:[], deciding:false,
  dayApproved:0, dayDenied:0, dayCorrect:0, dayWrong:0, dayMissed:0,
  dayDefaults:0, dayProfit:0,
};
const START_CAPITAL = 6000;
const el = id => document.getElementById(id);
function loadNum(k,d){ const v=parseFloat(localStorage.getItem(k)); return isNaN(v)?d:v; }
function saveNum(k,v){ try{ localStorage.setItem(k,String(v)); }catch(e){} }

const Game = {
  showScreen(name){
    S.screen = name;
    document.querySelectorAll('.screen').forEach(s=>s.classList.toggle('active', s.id === 'screen-'+name));
  },

  /* ---------- policy modal ---------- */
  openPolicy(){
    S.helpOpen = true;
    el('policy-modal').style.display = 'flex';
    el('help-btn').classList.add('active');
    SFX.tab();
  },
  closePolicy(){
    S.helpOpen = false;
    el('policy-modal').style.display = 'none';
    el('help-btn').classList.remove('active');
    SFX.click();
  },
  togglePolicy(){ if (S.helpOpen) Game.closePolicy(); else Game.openPolicy(); },

  /* ---------- run / day ---------- */
  startRun(){ SFX.resume(); S.day = 1; S.capital = START_CAPITAL; S.score = 0; S.streak = 0; Game.startDay(); },

  startDay(){
    S.paused = false; S.deciding = false;
    S.dayLength = 100; S.dayTimeLeft = 100;
    S.dayApplicants = 5 + S.day;
    S.spawnedCount = 0;
    S.spawnInterval = Math.max(4.5, 7 - S.day*0.3);
    S.spawnTimer = 0; S.queue = [];
    S.dayApproved = 0; S.dayDenied = 0; S.dayCorrect = 0; S.dayWrong = 0;
    S.dayMissed = 0; S.dayDefaults = 0; S.dayProfit = 0;
    S.helpOpen = false; el('policy-modal').style.display = 'none'; el('help-btn').classList.remove('active');
    Game.showScreen('play');
    const banner = el('day-banner'); banner.textContent = 'DAY ' + S.day;
    banner.classList.remove('show'); void banner.offsetWidth; banner.classList.add('show');
    Game.spawnApplicant();
    Game.renderActive();
    Game.updateHud();
    SFX.start();
  },
  nextDay(){ S.day++; Game.startDay(); },
  toTitle(){ S.paused = true; Game.refreshTitle(); Game.showScreen('title'); },

  /* ---------- queue ---------- */
  spawnApplicant(){
    if (S.spawnedCount >= S.dayApplicants) return;
    S.queue.push(generateApplication(S.day));
    S.spawnedCount++;
    S.spawnTimer = S.spawnInterval;
    if (S.queue.length === 1) Game.renderActive(); else Game.renderQueueStrip();
  },

  renderActive(){
    const app = S.queue[0];
    const win = el('window-box');
    Game.renderTally();
    if (!app){
      win.innerHTML = '<div class="cust"><div class="cust-meta"><div class="cust-name">Window closed</div><div class="cust-occ">waiting for the next applicant…</div></div></div>';
      el('view-app').classList.add('empty');
      Game.renderApplication(null);
      Game.renderQueueStrip();
      return;
    }
    win.innerHTML = '';
    const cust = document.createElement('div'); cust.className = 'cust';
    cust.appendChild(makeAvatar(app.avatarSeed, app.mood));
    const meta = document.createElement('div'); meta.className = 'cust-meta';
    meta.innerHTML = `<div class="cust-name">${app.name}</div><div class="cust-occ">${app.occupation}</div>
      <div class="patience" id="patience-bar"><i></i></div>`;
    cust.appendChild(meta);
    win.appendChild(cust);
    Game.renderApplication(app);
    Game.renderQueueStrip();
  },

  renderQueueStrip(){
    const strip = el('queue-strip'); if(!strip) return;
    strip.innerHTML = '';
    S.queue.slice(1,4).forEach(a=>{ const m = makeAvatar(a.avatarSeed,'neutral'); m.className='mini'; strip.appendChild(m); });
    const remaining = S.dayApplicants - S.spawnedCount + Math.max(0, S.queue.length-4);
    if (remaining > 0){ const more = document.createElement('span'); more.className='more'; more.textContent = '+'+remaining; strip.appendChild(more); }
  },

  renderTally(){
    el('tally-approved').textContent = S.dayApproved;
    el('tally-denied').textContent = S.dayDenied;
  },

  /* ---------- the application file ---------- */
  renderApplication(app){
    const body = el('appfile-body');
    const stamp = el('stamp');
    stamp.className = 'stamp';
    el('appfile').className = 'appfile';
    if (!app){
      el('appfile-num').textContent = '#----';
      body.innerHTML = '<div style="margin:auto;color:#9a8c63;font-size:22px;text-align:center">No application at the window.</div>';
      el('btn-approve').disabled = true; el('btn-deny').disabled = true;
      return;
    }
    el('btn-approve').disabled = false; el('btn-deny').disabled = false;
    el('appfile-num').textContent = '#' + String(app.id % 100000).padStart(5,'0');

    const dtiPct = Math.round(app.dtiAfter*100);
    const dtiOk = app.dtiAfter <= POLICY.maxDTI;
    const dtiFill = Math.min(app.dtiAfter/0.6, 1)*100;
    const dtiMark = (0.40/0.6)*100;
    const creditOk = app.creditScore >= POLICY.minCredit;
    const creditFill = Math.max(0, Math.min((app.creditScore-300)/550, 1))*100;
    const creditMark = ((600-300)/550)*100;
    const coll = app.collateral
      ? `${app.collateral.label} <small>· ${fmtMoney(app.collateral.value)}</small>`
      : '<small>none — unsecured</small>';
    const secured = app.secured ? 'SECURED' : 'UNSECURED';

    body.innerHTML = `
      <div class="app-id">
        <canvas class="avatar" width="16" height="16" id="app-av"></canvas>
        <div class="who"><div class="nm">${app.name}</div><div class="oc">${app.occupation}</div></div>
        <div class="ask"><div class="k">REQUESTS</div><div class="v">${fmtMoney(app.amount)}</div></div>
      </div>
      <div class="stat-grid">
        <div class="stat"><div class="k">MONTHLY INCOME</div><div class="v">${fmtMoney(app.income)}</div></div>
        <div class="stat"><div class="k">EXISTING DEBT /mo</div><div class="v">${fmtMoney(app.debt)}</div></div>
        <div class="stat"><div class="k">CREDIT SCORE</div><div class="v">${app.creditScore}</div></div>
        <div class="stat"><div class="k">LOAN TERM</div><div class="v">${app.term} <small>mo</small></div></div>
        <div class="stat"><div class="k">EST. PAYMENT /mo</div><div class="v">${fmtMoney(app.payment)}</div></div>
        <div class="stat"><div class="k">COLLATERAL</div><div class="v" style="font-size:13px">${coll}</div></div>
      </div>
      <div class="detail-row">
        <div class="purpose"><div class="k">PURPOSE OF LOAN</div>
          <div class="v">${app.purpose}
            <span class="ptag ${app.purposeBanned?'spec':''}">${app.purposeBanned?'SPECULATIVE':'PRODUCTIVE'}</span>
            <span class="ptag">${secured}</span>
          </div></div>
      </div>
      <div class="worksheet">
        <div class="gauge">
          <div class="glabel">DEBT-TO-INCOME</div>
          <div class="track"><div class="fill ${dtiOk?'ok':'bad'}" style="width:${dtiFill}%"></div>
            <div class="mark" style="left:${dtiMark}%"><b>40% MAX</b></div></div>
          <div class="gval ${dtiOk?'ok':'bad'}">${dtiPct}%</div>
        </div>
        <div class="gauge">
          <div class="glabel">CREDIT SCORE</div>
          <div class="track"><div class="fill ${creditOk?'ok':'bad'}" style="width:${creditFill}%"></div>
            <div class="mark" style="left:${creditMark}%"><b>600 MIN</b></div></div>
          <div class="gval ${creditOk?'ok':'bad'}">${app.creditScore}</div>
        </div>
      </div>`;
    const av = el('app-av');
    if (av){ const big = makeAvatar(app.avatarSeed, app.mood); const c = av.getContext('2d'); c.drawImage(big,0,0); }
  },

  /* ---------- decision ---------- */
  decide(choice){
    if (S.screen !== 'play' || S.paused || S.deciding) return;
    const app = S.queue[0];
    if (!app || app.resolved) return;
    S.deciding = true; app.resolved = true;

    // stamp
    const stamp = el('stamp');
    stamp.textContent = choice === 'approve' ? 'APPROVED' : 'DENIED';
    stamp.className = 'stamp ' + choice;
    stamp.style.setProperty('--rot', choice === 'approve' ? '-13deg' : '11deg');
    void stamp.offsetWidth; stamp.classList.add('show');
    el('appfile').classList.add('stamped');
    if (choice === 'approve'){ S.dayApproved++; SFX.stampApprove(); } else { S.dayDenied++; SFX.stampDeny(); }

    const correct = (choice === app.correct);
    const interest = Math.round(app.amount * (0.08 + app.term/900));
    const defaultLoss = Math.round(app.amount * 0.55);
    let delta = 0, label = '', toastClass = '';

    if (correct){
      S.streak++; S.dayCorrect++;
      const sb = 1 + Math.min(S.streak*0.05, 0.5);
      if (choice === 'approve'){ delta = Math.round(interest*sb); label = 'GOOD LOAN  +' + fmtMoney(delta) + ' interest'; }
      else { delta = Math.round(interest*0.25*sb); label = 'GOOD CALL  avoided a bad loan'; }
      S.score += Math.round(120*sb);
      toastClass = 'good';
    } else {
      S.streak = 0; S.dayWrong++;
      if (choice === 'approve'){ delta = -defaultLoss; S.dayDefaults++;
        label = 'DEFAULT!  ' + app.name + ' can\u2019t repay  ' + fmtMoney(delta); }
      else { delta = 0; label = 'TOO HARSH  ' + app.name + ' was a safe bet'; }
      S.score = Math.max(0, S.score - 40);
      toastClass = 'bad';
    }
    S.capital += delta; S.dayProfit += delta;

    Game.reactAvatar(choice === 'approve' ? 'happy' : 'angry');
    el('appfile').classList.add(correct ? 'flash-ok' : 'flash-bad');
    if (delta !== 0) Game.float((delta>0?'+':'') + fmtMoney(delta), delta>0?'#2c7d42':'#a82f25');
    Game.toast(label, toastClass);
    if (correct) SFX.coin(); else if (choice==='approve') setTimeout(()=>SFX.bad(),200);
    Game.updateHud();

    if (S.capital < 0){ setTimeout(()=>Game.gameOver(), 700); return; }

    setTimeout(()=>{
      S.queue.shift(); S.deciding = false;
      if (S.queue.length === 0 && S.spawnedCount < S.dayApplicants) S.spawnTimer = Math.min(S.spawnTimer, 0.6);
      Game.renderActive();
      Game.checkDayEnd();
    }, 850);
  },

  reactAvatar(mood){
    const app = S.queue[0]; if(!app) return; app.mood = mood;
    const wb = el('window-box'); const old = wb.querySelector('.cust .avatar');
    if (old){ const av = makeAvatar(app.avatarSeed, mood); av.classList.add('pop'); old.replaceWith(av); }
  },

  applicantLeaves(){
    const app = S.queue[0]; if(!app || app.resolved) return;
    app.resolved = true; S.dayMissed++; S.streak = 0;
    SFX.leave();
    Game.reactAvatar('angry');
    Game.toast(app.name + ' got tired of waiting and left', 'bad');
    Game.updateHud();
    setTimeout(()=>{ S.queue.shift();
      if (S.queue.length === 0 && S.spawnedCount < S.dayApplicants) S.spawnTimer = Math.min(S.spawnTimer, 0.6);
      Game.renderActive(); Game.checkDayEnd();
    }, 450);
  },

  /* ---------- day end ---------- */
  checkDayEnd(){
    if (S.spawnedCount >= S.dayApplicants && S.queue.length === 0 && S.screen === 'play') Game.endDay('clear');
  },
  endDay(reason){
    if (S.screen !== 'play') return;
    S.paused = true;
    const best = Math.max(loadNum('bank_best', 0), S.capital);
    saveNum('bank_best', best);
    const total = S.dayCorrect + S.dayWrong;
    const acc = total ? Math.round(S.dayCorrect/total*100) : 0;
    el('result-head').className = 'result-head';
    el('result-head').textContent = (reason === 'time' ? "BANK CLOSES" : 'DAY ' + S.day + ' COMPLETE');
    el('result-body').innerHTML = `
      <div class="stat-row"><span>Correct decisions</span><span class="v green">${S.dayCorrect}/${total}</span></div>
      <div class="stat-row"><span>Loans defaulted</span><span class="v ${S.dayDefaults?'red':''}">${S.dayDefaults}</span></div>
      <div class="stat-row"><span>Applicants lost</span><span class="v ${S.dayMissed?'red':''}">${S.dayMissed}</span></div>
      <div class="stat-row"><span>Underwriting rating</span><span class="v">${acc}%</span></div>
      <div class="stat-row"><span>Today's profit</span><span class="v ${S.dayProfit>=0?'green':'red'}">${fmtMoney(S.dayProfit)}</span></div>
      <div class="stat-row"><span>Bank capital</span><span class="v green">${fmtMoney(S.capital)}</span></div>`;
    el('result-next').textContent = 'OPEN DAY ' + (S.day+1) + ' →';
    Game.showScreen('result');
    SFX.star();
  },
  gameOver(){
    S.paused = true;
    el('over-body').innerHTML = `
      <div class="stat-row"><span>Made it to</span><span class="v">DAY ${S.day}</span></div>
      <div class="stat-row"><span>Loans defaulted</span><span class="v red">${S.dayDefaults}</span></div>
      <div class="stat-row"><span>Final capital</span><span class="v red">${fmtMoney(S.capital)}</span></div>
      <div class="stat-row"><span>Best capital ever</span><span class="v">${fmtMoney(loadNum('bank_best',0))}</span></div>`;
    Game.showScreen('over');
    SFX.over();
  },

  /* ---------- feedback ---------- */
  toast(msg, cls){
    const t = document.createElement('div'); t.className = 'toast ' + (cls||''); t.textContent = msg;
    el('stage').appendChild(t); setTimeout(()=>t.remove(), 2200);
  },
  float(text, color){
    const f = document.createElement('div'); f.className='float'; f.textContent = text; f.style.color = color||'#fff';
    const a = el('appfile').getBoundingClientRect(), st = el('stage').getBoundingClientRect();
    const sc = st.width/1280;
    f.style.left = ((a.left - st.left)/sc + 150) + 'px';
    f.style.top  = ((a.top - st.top)/sc + 60) + 'px';
    el('stage').appendChild(f); setTimeout(()=>f.remove(), 1200);
  },

  refreshTitle(){ el('hi-best').textContent = fmtMoney(loadNum('bank_best', START_CAPITAL)); },

  /* ---------- loop ---------- */
  _last:0,
  loop(t){
    if (!Game._last) Game._last = t;
    let dt = (t - Game._last)/1000; Game._last = t;
    if (dt > 0.1) dt = 0.1;
    if (S.screen === 'play' && !S.paused && !S.helpOpen){
      S.dayTimeLeft -= dt;
      const app = S.queue[0];
      if (app && !app.resolved){ app.patience -= dt; if (app.patience <= 0) Game.applicantLeaves(); }
      S.spawnTimer -= dt;
      if (S.spawnedCount < S.dayApplicants && S.queue.length < 3 && S.spawnTimer <= 0) Game.spawnApplicant();
      Game.updateHud();
      if (S.dayTimeLeft <= 0) Game.endDay('time');
    }
    requestAnimationFrame(Game.loop);
  },

  updateHud(){
    el('hud-day').querySelector('.val').textContent = S.day;
    el('hud-time').querySelector('.val').textContent = Math.max(0, Math.ceil(S.dayTimeLeft));
    el('hud-apps').querySelector('.val').textContent = (S.dayApproved+S.dayDenied+S.dayMissed) + '/' + S.dayApplicants;
    el('hud-score').querySelector('.val').textContent = S.score;
    const cap = el('hud-cap'); cap.querySelector('.val').textContent = fmtMoney(S.capital);
    cap.classList.toggle('low', S.capital < 2000);
    const frac = Math.max(0, S.dayTimeLeft)/S.dayLength;
    const bar = el('day-bar'); bar.querySelector('i').style.width = (frac*100)+'%';
    bar.classList.toggle('warn', frac < 0.25);
    const app = S.queue[0]; const pb = el('patience-bar');
    if (pb && app){ const pf = Math.max(0, app.patience/app.patienceMax);
      pb.querySelector('i').style.transform = 'scaleX('+pf+')';
      pb.classList.toggle('mid', pf<0.5); pb.classList.toggle('low', pf<0.25);
    }
  },

  fit(){ el('stage').style.transform = 'scale(' + Math.min(window.innerWidth/1280, window.innerHeight/720) + ')'; },
};

/* ---------- input ---------- */
function bindInput(){
  el('btn-start').onclick = ()=>{ SFX.resume(); SFX.click(); Game.startRun(); };
  el('title-policy').onclick = (e)=>{ e.stopPropagation(); SFX.resume(); Game.togglePolicy(); };
  el('btn-approve').onclick = ()=> Game.decide('approve');
  el('btn-deny').onclick = ()=> Game.decide('deny');
  el('tab-app').onclick = ()=>{};
  el('help-btn').onclick = ()=> Game.togglePolicy();
  el('policy-close').onclick = ()=> Game.closePolicy();
  el('policy-modal').onclick = (e)=>{ if (e.target.id === 'policy-modal') Game.closePolicy(); };
  el('result-next').onclick = ()=>{ SFX.click(); Game.nextDay(); };
  el('result-quit').onclick = ()=>{ SFX.click(); Game.toTitle(); };
  el('over-retry').onclick = ()=>{ SFX.click(); Game.startRun(); };
  el('over-quit').onclick = ()=>{ SFX.click(); Game.toTitle(); };

  function toggleMute(){ const m = SFX.toggle(); saveNum('bank_muted', m?1:0);
    document.querySelectorAll('.mute-btn').forEach(b=> b.textContent = m ? '\uD83D\uDD07 OFF' : '\uD83D\uDD0A ON'); }
  document.querySelectorAll('.mute-btn').forEach(b=> b.onclick = (e)=>{ e.stopPropagation(); toggleMute(); });
  const crtBtn = el('crt-btn');
  crtBtn.onclick = (e)=>{ e.stopPropagation(); el('crt').classList.toggle('off');
    crtBtn.textContent = el('crt').classList.contains('off') ? 'CRT OFF' : 'CRT ON'; };

  window.addEventListener('keydown', e=>{
    if (S.screen === 'title' && (e.key===' '||e.key==='Enter')){ e.preventDefault(); SFX.resume(); Game.startRun(); return; }
    if (S.screen === 'result' && (e.key===' '||e.key==='Enter')){ e.preventDefault(); Game.nextDay(); return; }
    if (S.screen === 'over' && (e.key===' '||e.key==='Enter')){ e.preventDefault(); Game.startRun(); return; }
    if (S.screen !== 'play') return;
    const k = e.key.toLowerCase();
    if (e.key === 'Escape'){ if (S.helpOpen) Game.closePolicy(); return; }
    if (k === '?' || e.key === '/' || k === 'p' || k === 'h'){ e.preventDefault(); Game.togglePolicy(); return; }
    if (S.helpOpen) return;
    if (k === 'a' || e.key === 'ArrowRight'){ e.preventDefault(); Game.decide('approve'); return; }
    if (k === 'd' || e.key === 'ArrowLeft'){ e.preventDefault(); Game.decide('deny'); return; }
  });
  window.addEventListener('resize', Game.fit);
}

window.addEventListener('DOMContentLoaded', ()=>{
  bindInput();
  if (loadNum('bank_muted',0)){ SFX.toggle(); document.querySelectorAll('.mute-btn').forEach(b=> b.textContent='\uD83D\uDD07 OFF'); }
  Game.refreshTitle(); Game.fit(); Game.showScreen('title');
  requestAnimationFrame(Game.loop);
});
